import { useState, useEffect } from 'react';
import axiosInstance from './axiosInstance';
import bgImage from '../assets/bg1.jpg';

const useAuth = () => {
  const [token, setToken] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isMfa, setIsMfa] = useState(false);
  const [user, setUser] = useState('');
  const [isMfaAuthenticated, setIsMfaAuthenticated] = useState(false);
  const [bodyBackgroundImage, setBodyBackgroundImage] = useState(`url(${bgImage})`);


  useEffect(() => {
    const storedToken = localStorage.getItem('token');
    if (storedToken) {
      setToken(storedToken);
      setIsAuthenticated(true);
      setBodyBackgroundImage('none')
    }
  }, []);


  useEffect(() => {
    const checkTokenExpiration = setTimeout(() => {
      if (token) {
        localStorage.removeItem('token');
        setToken(null);
        setIsAuthenticated(false);
        setIsMfa(false);
        setIsMfaAuthenticated(false);
      }
    }, 3000000);

    return () => clearTimeout(checkTokenExpiration);
  }, [token]);

  const handleLogin = async (endpoint, data) => {
    try {
      const response = await axiosInstance.post(endpoint, data);
      const responseData = response.data;  
      if (responseData.token && responseData.username) {
        setToken(responseData.token);
        setUser(responseData.username);
        setIsAuthenticated(true);
        setBodyBackgroundImage('none')
        localStorage.setItem('token', responseData.token);  
      }
      if (endpoint === '/mfa') {
        setIsMfa(true);
        setIsMfaAuthenticated(true);
      }
    } catch (error) {
      if (error.response) {
        console.error('Server responded with error:', error.response.data);
      } else if (error.request) {
        console.error('No response received:', error.request);
      } else {
        console.error('Error setting up the request:', error.message);
      }
    }
  };

  const handleCredentialsLogin = async (username, password) => {
    await handleLogin('/login', { username, password });
  };
  

  const handleMfaLogin = async (otp) => {
    if (isAuthenticated) {
      await handleLogin('/mfa', { otp });
    } else {
      console.error('User is not authenticated.');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    setToken(null);
    setIsAuthenticated(false);
    setIsMfa(false);
    setIsMfaAuthenticated(false);
    setUser('');
  };

  console.log(isAuthenticated)
  return {
    user,
    isAuthenticated,
    isMfa,
    isMfaAuthenticated,
    bodyBackgroundImage,
    handleCredentialsLogin,
    handleMfaLogin,
    handleLogout,
  };
};

export default useAuth;

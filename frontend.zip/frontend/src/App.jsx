import React from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import AppRoutes from './components/AppRoutes';
import useAuth from './components/useAuth';
import NavigationBar from './components/NavigationBar';

const App = () => {
  const { bodyBackgroundImage } = useAuth();

  return (
    <Router>
      <div style={{ backgroundImage: bodyBackgroundImage, backgroundSize: 'cover', backgroundPosition: 'center', backgroundRepeat: 'no-repeat', overflow: 'hidden', height: '100vh' }}>
        <NavigationBar />
        <AppRoutes />
      </div>
    </Router>
  );
};

export default App;

import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import NavigationBar from './components/NavigationBar';
import LoginPage from './components/LoginPage';
import MfaPage from './components/MfaPage'; 
import Dashboard from './components/Dashboard'; 
import bgImage from './assets/bg1.jpg';

const PrivateRoute = ({ component: Component, ...rest }) => {
  const { isAuthenticated, isMfa } = rest;
  if (isMfa) {
    return isAuthenticated && isMfa ? <Component {...rest} /> : <Navigate to="/" />;
  } else {
    return isAuthenticated && !isMfa ? <Component {...rest} /> : <Navigate to="/" />;
  }
};

const App = () => {
  const [username, setUsername] = useState(''); 
  const [isAuthenticated, setisAuthenticated] = useState(false);
  const [isMfa, setIsMfa] = useState(false);
  const [bodyBackgroundImage, setBodyBackgroundImage] = useState(`url(${bgImage})`);

  useEffect(() => {
    if (isAuthenticated && isMfa) {
      setBodyBackgroundImage('none');
    } else {
      setBodyBackgroundImage(`url(${bgImage})`);
    }
  }, [isAuthenticated, isMfa]);

  const handleCredentialsLogin = () => {
    setisAuthenticated(true);
    setIsMfa(false);
  };  
  const handleMfaLogin = () => {
    setisAuthenticated(true);
    setIsMfa(true);
    setUsername('revanth.bolli@constellaintelligence.com');
  };
  const handleLogout = () => {
    setisAuthenticated(false);
    setIsMfa(false);
    setUsername('');
  };

  return (
    <Router>
      <div style={{ backgroundImage: bodyBackgroundImage, backgroundSize: 'cover', backgroundPosition: 'center', backgroundRepeat: 'no-repeat', overflow: 'hidden', height:"100vh" }}>
        <NavigationBar 
          username={username} 
          isAuthenticated={isAuthenticated} 
          isMfa={isMfa} 
          onLogout={handleLogout} 
        /> 
        
        <Routes>
          {/* Home/Login Page */}
          <Route 
            path="/" 
            element={<LoginPage onLogin={handleCredentialsLogin} />} 
          />

          {/* MFA Route */}
          <Route 
            path="/mfa" 
            element={<PrivateRoute component={MfaPage} username={username} isAuthenticated={isAuthenticated} isMfa={isMfa} onMfa={handleMfaLogin} />} 
          />
          
          {/* Dashboard Route */}
          <Route 
            path="/dashboard" 
            element={<PrivateRoute component={Dashboard} username={username} isAuthenticated={isAuthenticated} isMfa={isMfa} />}
          />



          {/* Add other routes/components here if needed */}
        </Routes>
      </div>
    </Router>
  );
};

export default App;


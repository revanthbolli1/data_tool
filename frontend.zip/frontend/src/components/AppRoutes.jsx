import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import useAuth from './useAuth';
import LoginPage from './LoginPage';
import MfaPage from './MfaPage';
import Dashboard from './Dashboard';
import PrivateRoute from './PrivateRoute';

const AppRoutes = () => {
  const { isAuthenticated, isMfaAuthenticated, handleCredentialsLogin } = useAuth();

  return (
    <Routes>
      <Route path="/" element={<LoginPage onLogin={ handleCredentialsLogin }/>} />
      <Route path="/verify" element={isAuthenticated ? <MfaPage /> : <Navigate to="/" />} />
      {/* <PrivateRoute path="/dashboard" element={<Dashboard />} isMfaRequired={isMfaAuthenticated} /> */}
      {/* Add other routes/components here if needed */}
    </Routes>
  );
};

export default AppRoutes;

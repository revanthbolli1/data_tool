import load from "../assets/load1.gif"
import React from 'react';

const Loading = () => {
  return (
    <div
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        // backgroundColor: 'rgba(0, 0, 0, 0.6)', 
        // backdropFilter: 'blur(5px)', 
        zIndex: 9999, 
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center', 
      }}
    >
      <img src={load} alt="Loading" style={{ width: '150px', height: '150px' }} />
    </div>
  );
};

export default Loading;


import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button, Container, IconButton, TextField, Typography, Tooltip } from '@mui/material';
import { Visibility, VisibilityOff, Info, Lock } from '@mui/icons-material';

const MfaForm = ({ onMfa }) => {
  const [mfaCode, setMfaCode] = useState('');
  const [showMfaCode, setShowMfaCode] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (error || mfaCode.trim().length === 0) {
      return;
    }
    
    if (!/^\d{6}$/.test(mfaCode.trim())) {
      setError('Please enter a valid 6-digit 2FA code.');
      return;
    }
    // Validate MFA code
    // Redirect to dashboard if valid
    onMfa();
    navigate('/dashboard');
  };


  const handleMfaCodeChange = (e) => {
    const code = e.target.value;
    setMfaCode(code);

    if ((code.length < 6) || (code.length > 6) || (!/^\d{6}$/.test(code))) {
      setError('Please enter a valid 6-digit 2FA code.');
    } else {
      setError('');
    }
  };

  const toggleMfaCodeVisibility = () => {
    setShowMfaCode(!showMfaCode);
  };

  return (
    <Container component="main" maxWidth="xs">
      <div className="mfa-container">
        <Typography component="h1" variant="h5" style={{ marginBottom: '3rem', color: '#CCCCCC', fontWeight: 'bold' }}>
          Two-Factor Authentication(2FA)
        </Typography>
        <form onSubmit={handleSubmit}>
          <TextField
            autoFocus
            variant="outlined"
            margin="normal"
            fullWidth
            label="Authentication code*"
            type={showMfaCode ? 'text' : 'password'}
            value={mfaCode}
            onChange={handleMfaCodeChange}
            error={Boolean(error)}
            helperText={error}
            InputLabelProps={{ style: { color: 'white' } }}
            InputProps={{
              sx: { fontSize: '16px', color: 'white', width: '100%' },
              endAdornment: (
                <React.Fragment>
                <Tooltip title="Enter the 2FA code shown in the authenticator." arrow>
                  <Info style={{ color: 'CCCCCC', marginRight: '8px', fontSize: '18px', cursor: 'pointer'}} />
                </Tooltip>
                <IconButton onClick={toggleMfaCodeVisibility} edge="end">
                  {showMfaCode ? <VisibilityOff style={{ color: 'white' }} /> : <Visibility style={{ color: 'white' }} />}
                </IconButton>
              </React.Fragment>
              ),
            }}
            className="green-border"
          />
          <Button
            type="submit"
            fullWidth
            variant="contained"
            color= "success"
            size="large"
            style={{ marginTop: '1rem', opacity: error || mfaCode.trim().length ===0 ? 0.5 : 1, cursor: error || mfaCode.trim().length ===0 ? 'not-allowed' : 'pointer' }}
          >
            {error || mfaCode.trim().length ===0 ? (
              <>
                Verify
                <Lock style={{ marginRight: '0.5rem' }} />
              </>
            ) : (
              'Verify'
            )}
          </Button>
        </form>
      </div>
    </Container>
  );
};

export default MfaForm;

import React from 'react';
import { Route, Navigate } from 'react-router-dom';
import useAuth from './useAuth';

const PrivateRoute = ({ path, element, isMfaRequired }) => {
  const { isAuthenticated, isMfa, isMfaAuthenticated } = useAuth();

  if (!isAuthenticated) {
    return <Navigate to="/" />;
  }

  if (isMfaRequired && (!isMfa || !isMfaAuthenticated)) {
    return <Navigate to="/mfa" />;
  }

  return <Route path={path} element={element} />;
};

export default PrivateRoute;

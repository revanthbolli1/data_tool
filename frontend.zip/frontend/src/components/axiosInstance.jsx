import axios from 'axios';
import MockAdapter from 'axios-mock-adapter';

const axiosInstance = axios.create({
  baseURL: 'https://4iq.api.com',
  headers: {
    'Content-Type': 'application/json',
  },
});



const mock = new MockAdapter(axiosInstance);

// Mock POST /login request
mock.onPost('/login').reply(200, {
  token: 'mockedToken123',
  username: 'mockedUsername',
}); 


axiosInstance.interceptors.request.use(
  async (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

export default axiosInstance;

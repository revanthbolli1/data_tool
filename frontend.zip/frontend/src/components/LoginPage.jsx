import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button, Container, IconButton, TextField, Typography } from '@mui/material';
import { Visibility, VisibilityOff, Lock } from '@mui/icons-material';

const LoginForm = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [usernameError, setUsernameError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();

    if (usernameError || passwordError || username.trim().length === 0 || password.trim().length === 0) {
      return;
    }

    if (!username.trim()) {
      setUsernameError('Please enter a username.');
      return;
    } else {
      setUsernameError('');
    }

    if (!password.trim()) {
      setPasswordError('Please enter a password.');
      return;
    } else {
      setPasswordError('');
    }

    // Validate username and password
    // Redirect to MFA page if valid
    onLogin();
    navigate('/verify');
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  return (
    <Container component="main" maxWidth="xs">
      <div className="login-container">
        <Typography component="h1" variant="h5" style={{ marginBottom: '1rem', color: '#CCCCCC', fontWeight: 'bold' }}>
          LOGIN
        </Typography>
        <form onSubmit={handleSubmit}>
          <TextField
            autoFocus
            InputProps={{ sx: { fontSize: '16px', color: 'white' } }}
            InputLabelProps={{ style: { color: 'white' } }}
            variant="outlined"
            margin="normal"
            fullWidth
            label="Username*"
            value={username}
            onChange={(e) => {
              setUsername(e.target.value);
              setUsernameError('');
            }}
            helperText={usernameError}
            error={Boolean(usernameError)}
            className="blue-border"
          />

          <TextField
            variant="outlined"
            margin="normal"
            fullWidth
            label="Password*"
            type={showPassword ? 'text' : 'password'}
            value={password}
            onChange={(e) => {
              setPassword(e.target.value);
              setPasswordError('');
            }}
            helperText={passwordError}
            error={Boolean(passwordError)}
            InputLabelProps={{ style: { color: 'white' } }}
            InputProps={{
              sx: { fontSize: '18px', color: 'white' },
              endAdornment: (
                <IconButton onClick={togglePasswordVisibility} edge="end">
                  {showPassword ? <VisibilityOff style={{ color: 'white' }} /> : <Visibility style={{ color: 'white' }} />}
                </IconButton>
              ),
            }}
            className="blue-border"
          />

          <Button
            type="submit"
            fullWidth
            variant="contained"
            color="primary"
            size="large"
            style={{ marginTop: '1rem', opacity: usernameError || passwordError || username.trim().length === 0 || password.trim().length === 0 ? 0.5 : 1, cursor: usernameError || passwordError || username.trim().length === 0 || password.trim().length === 0 ? 'not-allowed' : 'pointer' }}
          >
            {usernameError || passwordError || username.trim().length === 0 || password.trim().length === 0? (
              <>
                LOGIN
                <Lock style={{ marginRight: '0.5rem' }} />
              </>
            ) : (
              'LOGIN'
            )}
          </Button>
        </form>
      </div>
    </Container>
  );
};

export default LoginForm;

import React from 'react';
import { Routes, Route } from 'react-router-dom';
import useAuth from './useAuth';
import LoginPage from './LoginPage';
import MfaPage from './MfaPage';
import Dashboard from './/Dashboard';
import PrivateRoute from './PrivateRoute';

const AppRoutes = () => {
  const { isAuthenticated, isMfaAuthenticated } = useAuth();

  return (
    <Routes>
      <Route path="/" element={<LoginPage />} />
      <PrivateRoute path="/mfa" element={<MfaPage />} isMfaRequired={true} />
      <PrivateRoute path="/dashboard" element={<Dashboard />} isMfaRequired={isMfaAuthenticated} />
      {/* Add other routes/components here if needed */}
    </Routes>
  );
};

export default AppRoutes;

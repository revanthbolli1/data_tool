import React, { useEffect, useState } from 'react';
import { Container, Typography } from '@mui/material';
import Loading from './Loading';

const Dashboard = ({ username }) => {
  const [isLoading, setLoading] = useState(true);

  useEffect(() => {
    const timeout = setTimeout(() => {
      setLoading(false);
    }, 3000);

    return () => clearTimeout(timeout);
  }, [isLoading]);

  return (
    <Container component="main" maxWidth="md">
      {isLoading ? (
        <Loading /> 
      ) : (
        <div className="dashboard-container" >
          <Typography component="h1" variant="h5" style={{ marginBottom: '1rem' }}>
            Welcome, {username}!
          </Typography>
          <Typography component="p" variant="body1" style={{ marginBottom: '2rem' }}>
            This is your dashboard. You can add more content and features here.
          </Typography>
        </div>
      )}
    </Container>
  );
};

export default Dashboard;

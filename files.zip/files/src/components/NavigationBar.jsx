import React from 'react';
import { AppBar, Toolbar, Typography, IconButton, Box } from '@mui/material';
import { Logout } from '@mui/icons-material';
import companylogo from '../assets/constella.png';
import { useNavigate } from 'react-router-dom';

const NavigationBar = ({ username, isAuthenticated, isMfa, onLogout }) => {
  const navigate = useNavigate();

  const handleLogoutClick = () => {
    onLogout(); 
    navigate('/');  
  };

  return (
    <AppBar position="static" sx={{ backgroundColor: 'rgba(0, 0, 0, 0.98)' }}>
      <Toolbar sx={{ display: 'flex', justifyContent: 'space-between' }}>
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          <img 
            src={companylogo}
            alt="company-logo" 
            style={{ width: '150px', height: '60px', padding: '8px'}} 
          />
          </Box>
          {isAuthenticated && isMfa && (
            <Box sx={{ display: 'flex', alignItems: 'center', marginLeft: '10px' }}>
              <Typography variant="h7" component="div" sx={{ color: 'white' }}>
                {username}
              </Typography>
              <IconButton color="inherit" onClick={handleLogoutClick} sx={{ marginLeft: '10px' }}>
                <Logout />
              </IconButton>
            </Box>
          )}
        
      </Toolbar>
    </AppBar>
  );
};

export default NavigationBar;

import { useState, useEffect } from 'react';
import axiosInstance from './axiosInstance';
import bgImage from '../assets/bg1.jpg';

const useAuth = () => {
  const [token, setToken] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isMfa, setIsMfa] = useState(false);
  const [username, setUsername] = useState('');
  const [isMfaAuthenticated, setIsMfaAuthenticated] = useState(false);
  const [bodyBackgroundImage, setBodyBackgroundImage] = useState(`url(${bgImage})`);

  useEffect(() => {
    const storedToken = localStorage.getItem('token');
    if (storedToken) {
      setToken(storedToken);
      setIsAuthenticated(true);
      setBodyBackgroundImage('none')
    }
  }, []);

  useEffect(() => {
    const checkTokenExpiration = setTimeout(() => {
      if (token) {
        localStorage.removeItem('token');
        setToken(null);
        setIsAuthenticated(false);
        setIsMfa(false);
        setIsMfaAuthenticated(false);
      }
    }, 3600000);

    return () => clearTimeout(checkTokenExpiration);
  }, [token]);

  const handleLogin = async (endpoint, data) => {
    try {
      const response = await axiosInstance.post(endpoint, data);
      const responseData = response.data;
      localStorage.setItem('token', responseData.token);
      setToken(responseData.token);
      setIsAuthenticated(true);
      if (endpoint === '/mfa') {
        setIsMfa(true);
        setIsMfaAuthenticated(true);
      }
      setUsername(responseData.username);
    } catch (error) {
      console.error('Login error:', error);
    }
  };

  const handleCredentialsLogin = async (username, password) => {
    await handleLogin('/login', { username, password });
  };

  const handleMfaLogin = async (otp) => {
    if (isAuthenticated) {
      await handleLogin('/mfa', { otp });
    } else {
      console.error('User is not authenticated.');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    setToken(null);
    setIsAuthenticated(false);
    setIsMfa(false);
    setIsMfaAuthenticated(false);
    setUsername('');
  };

  return {
    username,
    isAuthenticated,
    isMfa,
    isMfaAuthenticated,
    bodyBackgroundImage,
    handleCredentialsLogin,
    handleMfaLogin,
    handleLogout,
  };
};

export default useAuth;
